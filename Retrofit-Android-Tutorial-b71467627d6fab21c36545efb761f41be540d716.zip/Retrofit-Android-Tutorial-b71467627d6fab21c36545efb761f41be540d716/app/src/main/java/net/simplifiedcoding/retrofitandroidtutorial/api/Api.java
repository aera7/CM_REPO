package net.simplifiedcoding.retrofitandroidtutorial.api;

import net.simplifiedcoding.retrofitandroidtutorial.models.LoginResponse;
import net.simplifiedcoding.retrofitandroidtutorial.models.UsersResponse;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by cyril.elbaz on 07/09/2018.
 */

public interface Api {

    @FormUrlEncoded
    @POST("createuser")
    Call<ResponseBody>  createUser(
                @Field("name") String name
            );

    @FormUrlEncoded
    @POST("userlogin")
    Call<ResponseBody> userLogin(
            @Field("name") String name
    );

    @FormUrlEncoded
    @POST("showfriends")
    Call<ResponseBody> showFriends(
            @Field("name") String name
    );

    @FormUrlEncoded
    @POST("friendsList")
    Call<UsersResponse> friendsList(
            @Field("name") String name
    );
}
