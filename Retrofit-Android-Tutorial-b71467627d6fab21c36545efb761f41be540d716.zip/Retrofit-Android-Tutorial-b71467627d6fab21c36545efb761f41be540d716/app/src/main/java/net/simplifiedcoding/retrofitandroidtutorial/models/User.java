package net.simplifiedcoding.retrofitandroidtutorial.models;

/**
 * Created by cyril.elbaz on 10/09/2018.
 */

public class User {
    private String name;
    private double rate;
    private double amount;

    public User(String name) {
        this.name = name;
    }

    public User(String name, double rate, double amount) {
        this.name = name;
        this.rate = rate;
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public double getRate() {
        return rate;
    }

    public double getAmount() {
        return amount;
    }
}
