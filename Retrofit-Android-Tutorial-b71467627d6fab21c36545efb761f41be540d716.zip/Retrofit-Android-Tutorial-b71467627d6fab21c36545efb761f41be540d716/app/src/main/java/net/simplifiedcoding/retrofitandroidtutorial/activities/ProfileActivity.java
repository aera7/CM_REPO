package net.simplifiedcoding.retrofitandroidtutorial.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationMenu;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import net.simplifiedcoding.retrofitandroidtutorial.R;
import net.simplifiedcoding.retrofitandroidtutorial.api.RetrofitClient;
import net.simplifiedcoding.retrofitandroidtutorial.fragments.HomeFragment;
import net.simplifiedcoding.retrofitandroidtutorial.fragments.SettingsFragment;
import net.simplifiedcoding.retrofitandroidtutorial.fragments.UsersFragment;
import net.simplifiedcoding.retrofitandroidtutorial.models.User;
import net.simplifiedcoding.retrofitandroidtutorial.storage.SharedPrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener, BottomNavigationView.OnNavigationItemSelectedListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        User user = SharedPrefManager.getInstance(this).getUser();

        BottomNavigationView navigationView = findViewById(R.id.bottom_nav);
        navigationView.setOnNavigationItemSelectedListener(this);


        findViewById(R.id.buttonFriendsList).setOnClickListener(this);
        findViewById(R.id.buttonLogout).setOnClickListener(this);
    }

    private void display_fragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .commit();
    }

    @Override
    protected void onStart() {
        super.onStart();


        if(!SharedPrefManager.getInstance(this).isLoggedIn()) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }

    }
    private void showFriends() {
        String name = SharedPrefManager.getInstance(ProfileActivity.this).getUser().getName();

        Call<ResponseBody> call = RetrofitClient
                .getmInstance()
                .getApi()
                .showFriends(name);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                try {
                    String s = response.body().string();

                    if( s != null ) {
                        try {
                             Toast.makeText(ProfileActivity.this, s, Toast.LENGTH_SHORT).show();

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(ProfileActivity.this, "ERROR1", Toast.LENGTH_SHORT).show();
                    // e.printStackTrace();
                }

            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                try {
                    Toast.makeText(ProfileActivity.this, "ERROR2", Toast.LENGTH_SHORT).show();
                } catch ( Exception e) {
                    Toast.makeText(ProfileActivity.this, "ERROR3", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void logout() {
        SharedPrefManager.getInstance(this).clear();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

    }

    @Override
    public void onClick(View v) {
        //Toast.makeText(ProfileActivity.this, "CLICK", Toast.LENGTH_SHORT).show();

        switch(v.getId()) {
            case R.id.buttonFriendsList:
                showFriends();
                break;
            case R.id.buttonLogout:
                logout();
                break;

        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment fragment = null;

        switch (item.getItemId()) {
            case R.id.menu_home:
                fragment = new HomeFragment();
                break;
            case R.id.menu_friends:
                fragment = new UsersFragment();
                break;
            case R.id.menu_settings:
                fragment = new SettingsFragment();
                break;
        }
        if (fragment != null){
            display_fragment(fragment);
        }
        return false;
    }
}
